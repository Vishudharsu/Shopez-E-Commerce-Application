import React from 'react'
import { Login } from '../features/auth/components/Login'

export const LoginPage = () => {
  return (
    <Login/>
  )
}
