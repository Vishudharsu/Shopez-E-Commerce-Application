import React from 'react'
import { ForgotPassword } from '../features/auth/components/ForgotPassword'

export const ForgotPasswordPage = () => {
  return (
    <ForgotPassword/>
  )
}
