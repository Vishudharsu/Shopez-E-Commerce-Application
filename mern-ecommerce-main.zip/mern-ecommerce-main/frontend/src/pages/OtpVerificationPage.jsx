import React from 'react'
import { OtpVerfication } from '../features/auth/components/OtpVerfication'

export const OtpVerificationPage = () => {
  return (
    <OtpVerfication/>
  )
}
